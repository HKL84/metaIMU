

# R code to install packages if not already installed    #shiny cheat sheet can be found here https://shiny.rstudio.com/images/shiny-cheatsheet.pdf
my_packages = c("shiny", "shinythemes", "dplyr", "tidyverse", "ggplot2", "gridExtra", "readxl","shinyscreenshot")
install_if_missing = function(p) {
  if (p %in% rownames(installed.packages()) == FALSE) {
    install.packages(p)
  }
}
invisible(sapply(my_packages, install_if_missing))

library(shiny)
library(shinythemes)
library(dplyr)
library(tidyverse)
library(ggplot2)
library(gridExtra)   
library(readxl)
library(shinyscreenshot)


ui <- fluidPage(theme = shinytheme("cerulean"),
                
                h1("MetaIMU"),  
                
                br(),
                
                h3("This application is created to aid researchers in producing high quality meta-analysis and systematic review"),
                
                br(),
                
                h5("This application is developed by Dr. Ho Ket Li, Dr. Haryo Sasongko and Dr. Lai Pei Kuan"),
                
                br(),
                
                h5("For any query or comments please contact via email: hoketli@imu.edu.my"),
                
                
                br(),
                
                sidebarPanel(tags$h3("Import and Export:"),
                             textInput(inputId = 'inputsLocation', label = 'To save and load your input type in your file name followed by .csv', value = "your_unique_file_name.csv"),
                             screenshotButton(filename="MetaIMU"),
                             actionButton('load_inputs', 'Load inputs'),
                             actionButton('save_inputs', 'Save inputs')
                ),
                
                mainPanel(
                  
                  navbarPage("Start here: What is the purpose of your systematic review?",
                             
                             tabPanel("I want to study efficacy and safety of a particular intervention against a particular condition or disease",
                                      
                                      h3("Step 1: Define review question (PICO)"),
                                      
                                      textAreaInput("input1.1", "input1.1: P: Which patient groups for population you want to focus? Avoid having a broad group e.g. cancer patients, babies, children, etc", value="", row=20, width="100%"),
                                      
                                      textAreaInput("input1.2", "input1.2: I: What experimental intervention you want to study? Be specific, e.g. name of the drug, dosage, administration", value="", row=20, width="100%"),
                                      
                                      textAreaInput("input1.3", "input1.3: C: What comparator intervention you want to compare the experimental intervention with? e.g. placebo, standard treatment, no treatment etc", value="", row=20, width="100%"),
                                      
                                      textAreaInput("input1.4", "input1.4: O: What outcome measures you want to study to prove the efficacy and safety of the intervention", value="", row=20, width="100%"),
                                      
                             ), # tabPanel 1
                             
                             tabPanel("I want to study the aetiology or risk factor of a particular condition or disease",
                                      
                                      
                             ), # tabPanel 2
                             
                             tabPanel("I want to summarise current body of evidence on a particular topic in medicine or healthcare",
                                      
                                      
                             ), # tabPanel 3
                             
                             tabPanel("None of the above represents my purpose.",
                                      
                                      
                             ), # tabPanel 4
                             
                             
                  ) #navbar Panel
                  
                ) #main Panel
                
) # fluidPage







#import datasets


server <- function(input, output, session) {
  
  observeEvent(input$load_inputs, {
    
    # Load inputs
    uploaded_inputs <- read.csv(input$inputsLocation)
    
    # Update each input
    for(i in 1:nrow(uploaded_inputs)){
      updateNumericInput(session,
                         inputId = uploaded_inputs$inputId[i],
                         value = uploaded_inputs$value[i])
    }
  })
  
  observeEvent(input$save_inputs, {
    # Define inputs to save
    inputs_to_save <- c("input1.1", "input1.2", "input1.3", "input1.4")
    
    # Declare inputs
    inputs <- NULL
    
    # Append all inputs before saving to folder
    for(input.i in inputs_to_save){
      inputs <- append(inputs, input[[input.i]])
    }
    
    # Inputs data.frame
    inputs_data_frame <- data.frame(inputId = inputs_to_save, value = inputs)
    
    # Save Inputs
    write.csv(inputs_data_frame, file = input$inputsLocation, row.names = FALSE)
  }) 
  
  
} # server


# Create Shiny object locally
shinyApp(ui = ui, server = server)